// api/ai.js — Vercel Serverless Function
// A chave OPENAI_KEY fica APENAS no servidor (variável de ambiente Vercel).
// O front-end nunca vê a chave. Qualquer chamada passa por aqui.

export default async function handler(req, res) {
  // CORS — permite apenas seu domínio em produção
  // Troque '*' pelo seu domínio real após deploy, ex: 'https://agrobaggio.vercel.app'
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'POST, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type');

  if (req.method === 'OPTIONS') {
    return res.status(200).end();
  }

  if (req.method !== 'POST') {
    return res.status(405).json({ error: 'Método não permitido' });
  }

  const OPENAI_KEY = process.env.OPENAI_KEY;
  if (!OPENAI_KEY) {
    return res.status(500).json({
      error: { message: 'OPENAI_KEY não configurada no servidor. Vá em Vercel > Settings > Environment Variables.' }
    });
  }

  try {
    const body = req.body;

    // Montar mensagens no formato OpenAI
    const messages = [];

    // System prompt
    if (body.system) {
      messages.push({ role: 'system', content: body.system });
    }

    // Mensagens do usuário (suporta texto + imagem base64)
    for (const msg of (body.messages || [])) {
      const role = msg.role === 'assistant' ? 'assistant' : 'user';
      if (Array.isArray(msg.content)) {
        const parts = [];
        for (const c of msg.content) {
          if (c.type === 'text') {
            parts.push({ type: 'text', text: c.text });
          } else if (c.type === 'image') {
            // Converte formato Anthropic → formato OpenAI vision
            parts.push({
              type: 'image_url',
              image_url: {
                url: `data:${c.source.media_type};base64,${c.source.data}`,
                detail: 'high'
              }
            });
          } else if (c.type === 'image_url') {
            parts.push(c); // já está no formato OpenAI
          }
        }
        messages.push({ role, content: parts });
      } else {
        messages.push({ role, content: msg.content });
      }
    }

    const openaiBody = {
      model:       body.model || 'gpt-4o',
      messages,
      max_tokens:  body.max_tokens || 4096,
      temperature: body.temperature || 0.7,
    };

    const response = await fetch('https://api.openai.com/v1/chat/completions', {
      method:  'POST',
      headers: {
        'Content-Type':  'application/json',
        'Authorization': `Bearer ${OPENAI_KEY}`,
      },
      body: JSON.stringify(openaiBody),
    });

    const data = await response.json();

    if (data.error) {
      return res.status(400).json({ error: data.error });
    }

    // Retorna no formato que o front-end espera
    const text = data.choices?.[0]?.message?.content || '';
    return res.status(200).json({
      content: [{ type: 'text', text }]
    });

  } catch (err) {
    console.error('Erro na Vercel Function:', err);
    return res.status(500).json({
      error: { message: `Erro interno: ${err.message}` }
    });
  }
}
